
# ============================================================
# BUILDING AGE CLASSIFICATION - IRAQ HACKATHON 2026
# COMPLETE EXPLORATORY DATA ANALYSIS (EDA)
# Dataset: Madrid
# ============================================================

from pathlib import Path

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import seaborn as sns

from scipy.stats import kruskal


# ============================================================
# 1. PROFESSIONAL SETTINGS
# ============================================================

sns.set_theme(
    style="whitegrid",
    context="notebook",
    palette="viridis"
)

plt.rcParams.update({
    "figure.figsize": (12, 7),
    "figure.dpi": 120,
    "savefig.dpi": 300,
    "font.size": 11,
    "axes.titlesize": 15,
    "axes.labelsize": 12,
    "xtick.labelsize": 10,
    "ytick.labelsize": 10,
    "figure.facecolor": "white",
    "axes.facecolor": "#FAFAFA",
    "savefig.bbox": "tight"
})

OUTPUT_DIR = Path("eda_outputs")
OUTPUT_DIR.mkdir(exist_ok=True)


# ============================================================
# 2. LOAD DATASET
# ============================================================

print("\n" + "=" * 65)
print("MADRID DATASET LOADING")
print("=" * 65)

files = list(
    Path.cwd().rglob("madrid_ready_for_noor.csv")
)

if not files:
    raise FileNotFoundError(
        "madrid_ready_for_noor.csv was not found!"
    )

file_path = files[0]

df = pd.read_csv(file_path)

print("\nDataset loaded successfully!")
print("File:", file_path)
print("Dataset Shape:", df.shape)

print("\nFirst 5 Rows:")
print(df.head())

print("\nColumn Names:")
print(df.columns.tolist())


# ============================================================
# 3. DATA QUALITY AUDIT
# ============================================================

print("\n" + "=" * 65)
print("DATA QUALITY AUDIT")
print("=" * 65)

print("\n[1] DATA TYPES")
print(df.dtypes.value_counts())

print("\n[2] MISSING VALUES")
print("Total Missing Values:", df.isnull().sum().sum())

missing = df.isnull().sum()
print("Columns with Missing Values:")
print(missing[missing > 0])

print("\n[3] DUPLICATE ROWS")
print("Total Duplicates:", df.duplicated().sum())

print("\n[4] TARGET VALIDATION")

if "target_class" not in df.columns:
    raise ValueError("target_class column is missing!")

print("Target Unique Values:")
print(sorted(df["target_class"].unique()))

print("\n[5] STATISTICAL SUMMARY")
print(df.describe().round(3))

print("\nDATA QUALITY AUDIT COMPLETED!")


# ============================================================
# 4. CLASS DISTRIBUTION
# ============================================================

print("\n" + "=" * 65)
print("CLASS DISTRIBUTION ANALYSIS")
print("=" * 65)

class_counts = df["target_class"].value_counts().sort_index()

class_percentages = (
    df["target_class"].value_counts(normalize=True)
    .sort_index() * 100
)

class_summary = pd.DataFrame({
    "Count": class_counts,
    "Percentage": class_percentages
})

print("\nClass Distribution:")
print(class_summary.round(2))

print("\nTotal Samples:", len(df))
print("Number of Classes:", df["target_class"].nunique())

imbalance_ratio = (
    class_counts.max() / class_counts.min()
)

print("Imbalance Ratio:", round(imbalance_ratio, 3))

class_summary.to_csv(
    OUTPUT_DIR / "class_distribution.csv"
)


# ============================================================
# 5. FEATURE QUALITY ANALYSIS
# ============================================================

print("\n" + "=" * 65)
print("FEATURE QUALITY ANALYSIS")
print("=" * 65)

X = df.drop(columns=["target_class"])
y = df["target_class"]

# Constant features
constant_features = X.columns[
    X.nunique() <= 1
]

print("\n[1] CONSTANT FEATURES")
print("Number of Constant Features:", len(constant_features))
print(list(constant_features))

# Variance
feature_variance = X.var().sort_values()

print("\n[2] LOWEST 10 VARIANCE FEATURES")
print(feature_variance.head(10))

# Feature statistics
feature_quality = pd.DataFrame({
    "Mean": X.mean(),
    "Std": X.std(),
    "Variance": X.var(),
    "Unique_Values": X.nunique()
})

print("\n[3] FEATURE STATISTICS")
print(feature_quality.loc[constant_features])

feature_quality.to_csv(
    OUTPUT_DIR / "feature_quality.csv"
)

print("\nFEATURE QUALITY ANALYSIS COMPLETED!")


# ============================================================
# 6. DATA AVAILABILITY INVESTIGATION
# ============================================================

print("\n" + "=" * 65)
print("DATA AVAILABILITY INVESTIGATION")
print("=" * 65)

for column in ["has_early_data", "has_late_data"]:

    if column in df.columns:

        print(f"\n[{column}]")
        print(df[column].value_counts(dropna=False))

        print(f"\n{column} BY TARGET CLASS:")

        cross_table = pd.crosstab(
            df["target_class"],
            df[column]
        )

        print(cross_table)

        print("\nPERCENTAGE BY TARGET CLASS:")

        print(
            pd.crosstab(
                df["target_class"],
                df[column],
                normalize="index"
            ).mul(100).round(3)
        )

print("\nDATA AVAILABILITY INVESTIGATION COMPLETED!")


# ============================================================
# 7. CORRELATION ANALYSIS
# ============================================================

print("\n" + "=" * 65)
print("CORRELATION ANALYSIS")
print("=" * 65)

X_valid = X.loc[:, X.nunique() > 1]

pearson_corr = (
    X_valid.corrwith(y)
    .sort_values(key=abs, ascending=False)
)

spearman_corr = (
    X_valid.corrwith(y, method="spearman")
    .sort_values(key=abs, ascending=False)
)

print("\n[1] TOP 15 PEARSON CORRELATIONS")
print(pearson_corr.head(15).round(4))

print("\n[2] TOP 15 SPEARMAN CORRELATIONS")
print(spearman_corr.head(15).round(4))


# ============================================================
# 8. ETA SQUARED FEATURE RANKING
# ============================================================

print("\n" + "=" * 65)
print("ETA SQUARED FEATURE RANKING")
print("=" * 65)

eta_scores = {}

overall_means = X_valid.mean()

for feature in X_valid.columns:

    ss_between = sum(
        len(group) *
        (group[feature].mean() - overall_means[feature]) ** 2
        for _, group in df.groupby("target_class")
    )

    ss_total = (
        (X_valid[feature] - overall_means[feature]) ** 2
    ).sum()

    eta_scores[feature] = (
        ss_between / ss_total
        if ss_total > 0 else 0
    )

eta_scores = pd.Series(eta_scores).sort_values(
    ascending=False
)

print("\nTOP 15 FEATURES BY ETA SQUARED:")
print(eta_scores.head(15).round(4))

ranking = pd.DataFrame({
    "Pearson": pearson_corr,
    "Spearman": spearman_corr,
    "Eta_Squared": eta_scores
})

ranking["Absolute_Pearson"] = ranking["Pearson"].abs()

ranking = ranking.sort_values(
    "Eta_Squared",
    ascending=False
)

ranking.to_csv(
    OUTPUT_DIR / "madrid_feature_ranking.csv"
)


# ============================================================
# 9. SPECTRAL COMPARISON BY CLASS
# ============================================================

print("\n" + "=" * 65)
print("SPECTRAL COMPARISON BY CLASS")
print("=" * 65)

spectral_features = [
    "NDVI_mean",
    "NDBI_mean",
    "UI_mean",
    "MNDWI_mean",
    "BSI_mean"
]

spectral_features = [
    col for col in spectral_features
    if col in df.columns
]

spectral_summary = (
    df.groupby("target_class")[spectral_features]
    .agg(["mean", "median", "std"])
)

print("\nSPECTRAL STATISTICS:")
print(spectral_summary.round(4))

spectral_summary.to_csv(
    OUTPUT_DIR / "madrid_spectral_summary.csv"
)


# ============================================================
# 10. TOP FEATURES STATISTICS BY CLASS
# ============================================================

print("\n" + "=" * 65)
print("TOP FEATURES DISTRIBUTION BY CLASS")
print("=" * 65)

top_features = eta_scores.head(5).index.tolist()

top_summary = (
    df.groupby("target_class")[top_features]
    .agg(["mean", "median", "std"])
)

print("\nTOP FEATURES STATISTICS:")
print(top_summary.round(4))

top_summary.to_csv(
    OUTPUT_DIR / "madrid_top_features_summary.csv"
)


# ============================================================
# 11. KRUSKAL-WALLIS STATISTICAL TEST
# ============================================================

print("\n" + "=" * 65)
print("KRUSKAL-WALLIS STATISTICAL TEST")
print("=" * 65)

results = []

for feature in X_valid.columns:

    groups = [
        df.loc[
            df["target_class"] == cls,
            feature
        ].values
        for cls in sorted(df["target_class"].unique())
    ]

    statistic, p_value = kruskal(*groups)

    results.append({
        "Feature": feature,
        "H_Statistic": statistic,
        "P_Value": p_value,
        "Eta_Squared": eta_scores[feature]
    })

stats_df = pd.DataFrame(results)


# ============================================================
# 12. BENJAMINI-HOCHBERG FDR CORRECTION
# ============================================================

stats_df = stats_df.sort_values(
    "P_Value"
).reset_index(drop=True)

m = len(stats_df)

ranks = np.arange(1, m + 1)

adjusted = (
    stats_df["P_Value"].values * m / ranks
)

adjusted = np.minimum.accumulate(
    adjusted[::-1]
)[::-1]

stats_df["FDR_Adjusted_P"] = np.clip(
    adjusted,
    0,
    1
)

stats_df["Significant"] = (
    stats_df["FDR_Adjusted_P"] < 0.05
)


# ============================================================
# 13. EPSILON SQUARED EFFECT SIZE
# ============================================================

n = len(df)
k = df["target_class"].nunique()

stats_df["Epsilon_Squared"] = (
    stats_df["H_Statistic"] - k + 1
) / (n - k)

stats_df["Epsilon_Squared"] = (
    stats_df["Epsilon_Squared"].clip(lower=0)
)

stats_df = stats_df.sort_values(
    "Epsilon_Squared",
    ascending=False
)

print("\nTOP 15 FEATURES BY KRUSKAL EFFECT SIZE:")

print(
    stats_df[
        [
            "Feature",
            "H_Statistic",
            "Epsilon_Squared",
            "FDR_Adjusted_P",
            "Significant"
        ]
    ].head(15).to_string(
        index=False,
        formatters={
            "H_Statistic": "{:.2f}".format,
            "Epsilon_Squared": "{:.4f}".format,
            "FDR_Adjusted_P": "{:.3e}".format
        }
    )
)

print("\nSIGNIFICANT FEATURES:",
      stats_df["Significant"].sum())

print("TOTAL TESTED FEATURES:", len(stats_df))

stats_df.to_csv(
    OUTPUT_DIR / "madrid_kruskal_results.csv",
    index=False
)


# ============================================================
# 14. PROFESSIONAL VISUALIZATION 1
# CLASS DISTRIBUTION
# ============================================================

fig, ax = plt.subplots(figsize=(10, 6))

sns.barplot(
    x=class_counts.index.astype(str),
    y=class_counts.values,
    hue=class_counts.index.astype(str),
    palette="viridis",
    legend=False,
    ax=ax
)

ax.set_title("Building Age Class Distribution", pad=18)
ax.set_xlabel("Building Age Class")
ax.set_ylabel("Number of Samples")

for container in ax.containers:
    ax.bar_label(container, fmt="%.0f", padding=4)

plt.tight_layout()

plt.savefig(
    OUTPUT_DIR / "01_class_distribution.png"
)

plt.close()


# ============================================================
# 15. PROFESSIONAL VISUALIZATION 2
# TOP FEATURES
# ============================================================

top15 = eta_scores.head(15).sort_values()

fig, ax = plt.subplots(figsize=(12, 8))

sns.barplot(
    x=top15.values,
    y=top15.index,
    hue=top15.index,
    palette="viridis",
    legend=False,
    ax=ax
)

ax.set_title("Top 15 Features by Eta Squared", pad=18)
ax.set_xlabel("Eta Squared")
ax.set_ylabel("Feature")

plt.tight_layout()

plt.savefig(
    OUTPUT_DIR / "02_top_features.png"
)

plt.close()


# ============================================================
# 16. PROFESSIONAL VISUALIZATION 3
# CORRELATION HEATMAP
# ============================================================

heatmap_features = eta_scores.head(12).index.tolist()

corr_data = df[
    heatmap_features + ["target_class"]
].corr()

fig, ax = plt.subplots(figsize=(13, 10))

sns.heatmap(
    corr_data,
    annot=True,
    fmt=".2f",
    cmap="coolwarm",
    center=0,
    linewidths=0.5,
    square=True,
    cbar_kws={"shrink": 0.8},
    ax=ax
)

ax.set_title(
    "Correlation Heatmap - Top Features",
    pad=18
)

plt.xticks(rotation=40, ha="right")
plt.yticks(rotation=0)

plt.tight_layout()

plt.savefig(
    OUTPUT_DIR / "03_correlation_heatmap.png"
)

plt.close()


# ============================================================
# 17. PROFESSIONAL VISUALIZATION 4
# TOP FEATURES BY CLASS
# ============================================================

fig, axes = plt.subplots(
    2, 3,
    figsize=(17, 10)
)

axes = axes.flatten()

for i, feature in enumerate(top_features):

    sns.boxplot(
        data=df,
        x="target_class",
        y=feature,
        color="#65A98F",
        showfliers=False,
        ax=axes[i]
    )

    axes[i].set_title(feature, pad=12)
    axes[i].set_xlabel("Building Age Class")
    axes[i].set_ylabel("Standardized Value")

axes[-1].axis("off")

fig.suptitle(
    "Top Feature Distributions Across Classes",
    fontsize=17,
    fontweight="bold"
)

plt.tight_layout()

plt.savefig(
    OUTPUT_DIR / "04_top_features_by_class.png"
)

plt.close()


# ============================================================
# 18. PROFESSIONAL VISUALIZATION 5
# SPECTRAL INDICES
# ============================================================

fig, axes = plt.subplots(
    2, 3,
    figsize=(17, 10)
)

axes = axes.flatten()

for i, feature in enumerate(spectral_features):

    sns.boxplot(
        data=df,
        x="target_class",
        y=feature,
        color="#E9A66B",
        showfliers=False,
        ax=axes[i]
    )

    axes[i].set_title(feature, pad=12)
    axes[i].set_xlabel("Building Age Class")
    axes[i].set_ylabel("Standardized Value")

axes[-1].axis("off")

fig.suptitle(
    "Spectral Indices Across Building Age Classes",
    fontsize=17,
    fontweight="bold"
)

plt.tight_layout()

plt.savefig(
    OUTPUT_DIR / "05_spectral_comparison.png"
)

plt.close()


# ============================================================
# 19. FINAL SUMMARY
# ============================================================

print("\n" + "=" * 65)
print("MADRID EDA COMPLETED SUCCESSFULLY!")
print("=" * 65)

print("\nDataset Shape:", df.shape)
print("Total Features:", len(X.columns))
print("Constant Features:", len(constant_features))
print("Missing Values:", df.isnull().sum().sum())
print("Duplicate Rows:", df.duplicated().sum())

print(
    "\nSignificant Features:",
    stats_df["Significant"].sum(),
    "/",
    len(stats_df)
)

print("\nOUTPUT FILES LOCATION:")
print(OUTPUT_DIR.resolve())

print("\nGenerated Files:")

for file in sorted(OUTPUT_DIR.iterdir()):
    print("-", file.name)

print("\nEDA PIPELINE FINISHED!")
